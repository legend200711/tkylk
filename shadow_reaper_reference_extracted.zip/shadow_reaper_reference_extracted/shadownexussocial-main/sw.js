/**
 * Shadow Nexus Social — Service Worker
 *
 * Strategy:
 *   - Navigation (HTML page loads) → Network-first, fallback to cache → offline.html
 *   - Same-origin assets (CSS/JS/icons) → Cache-first, network fallback
 *   - TV engine JS files              → Network-first, cache as offline fallback only
 *   - Firebase & external CDN requests  → Network-only (always fresh)
 *
 * Path detection: base is derived from sw.js location so this works on
 * shadownexussocial.online (/) and any local dev server (/).
 *
 * Build: SNS-2026-LIVE-ANDROID-FIX-001
 * Changes: Android-specific Live initialization repair.
 *   - live.js: All numeric separator literals (15_000, 90_000, 30_000, etc.)
 *     replaced with plain integers. Numeric separators are ES2021 and not
 *     supported on Android Chrome/WebView < 75 (installed PWA users on older
 *     devices). The SyntaxError at parse time prevented snxLivePageOpen from
 *     ever being defined — root cause of the stuck "Loading live streams…" and
 *     the "Live failed to initialize" error on Android while iPhone worked.
 *   - snx-sfu.js: Same numeric separator fix (96_000, 500_000, 900_000,
 *     10_000, 15_000 replaced with plain integers).
 *   - snx-feature-loader.js: _loadESModule now re-throws parse/import errors
 *     instead of swallowing them. loadFeature catch logs full [LIVE INIT ERROR]
 *     diagnostic object. [LIVE] 1-9 checkpoints added to the live load chain.
 *   - index.html: Live navTo failure path now replaces loading placeholder with
 *     "Live is temporarily unavailable" + RETRY LIVE button (no page reload,
 *     no duplicate Firebase listeners). BUILD_ID/SW_VER diagnostic values
 *     corrected from stale SNS-2026-STAGE2G-FINAL/v98 to
 *     SNS-2026-LIVE-ANDROID-FIX-001/v100.
 *   NOTE: CACHE_VERSION stays v100 — unchanged from SNS-2026-LIVE-REPAIR-001.
 *   The changed files (live.js, snx-sfu.js, snx-feature-loader.js, index.html)
 *   are all in TV_NETWORK_FIRST_FILES or SHELL_FILES and will be served fresh
 *   on next load without a cache bump. No new SW bump needed.
 *   - (Previous) SNS-2026-LIVE-REPAIR-001: Live.js moved to esModules[], v99→v100.
 *   - (Previous) SNS-2026-SHADOW-AI-STAGE1-001: Shadow Reaper AI Stage 1.
 *   - (Previous) SNS-2026-STAGE2G-FINAL: Stage 2F Runtime cleanup.
 *   v100
 */

const CACHE_VERSION = 'v101';
const BUILD_ID      = 'SNS-2026-SHADOW-RECONNECT-001';
const CACHE_NAME    = `shadow-nexus-${CACHE_VERSION}`;
const MEDIA_CACHE   = `shadow-nexus-media-${CACHE_VERSION}`;

// Detect base path from the SW's own URL (e.g. /ShadowNexusSocial/ or /)
const SW_URL  = new URL(self.location.href);
const BASE    = SW_URL.pathname.replace(/sw\.js$/, ''); // e.g. '/ShadowNexusSocial/' or '/'
const OFFLINE = BASE + 'offline.html';

/**
 * Files pre-cached on install — paths relative to BASE.
 *
 * Stage 2B policy:
 *   Only the true application shell is pre-cached.
 *   Feature-specific resources (Radio, Live, TV) are NOT pre-cached here.
 *   They are served via network-first on first use, then cached by the
 *   standard same-origin cache-first strategy on subsequent visits.
 *   This prevents the SW install from pre-fetching hundreds of KB of
 *   resources that a Feed-only user will never need.
 */
const SHELL_FILES = [
  '',            // root / index
  'index.html',
  'offline.html',
  'style.css',
  'album.css',
  'realm.css',
  'mobile.css',
  'profile-theme.css',
  'profile-music.css',
  'theme-engine.css',
  'script.js',
  'snx-net.js',
  'studio.css',
  'nexus.css',
  'nexus.js',
  'manifest.json',
  'icon-192.png',
  'icon-512.png',
  'apple-touch-icon.png',
  'favicon.ico',
  'favicon-32x32.png',
  'favicon-16x16.png',
  'version.json',
  'shadow-nexus-upgrade.js',
  'shadow-nexus-upgrade.css',
  'nexus-intro.js',
  'nexus-intro.css',
  'snx-perf.js',
  'snx-perf.css',
  'snx-feature-loader.js',  // Stage 2B: feature loader is shell
  'nexus-glass.css',
  'snx-stage11.css',
  'snx-world-bg.css',
  'assets/images/shadow-nexus-world.webp',
  'assets/images/shadow-nexus-global-bg.png',
  // Stage 2B: live.css, snx-sfu.js, live.js, snx-ch-adapter.js,
  // snx-tv-network.css, and all snx-radio.* files intentionally
  // NOT pre-cached — they are lazy-loaded and cached after first use.
];

/** Max entries for the media cache (CDN images / avatars). */
const MEDIA_CACHE_MAX = 100;
/** Max age for media cache entries (24 hours). */
const MEDIA_CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;

/** Paths that must always go to the network (never served from cache) */
const NETWORK_FIRST_PATHS = [];

/**
 * Network-first files — always fetched from network; cache is offline fallback only.
 * The browser must NEVER prefer a stale cached version of these over the deployed version.
 *
 * Stage 2B: deferred feature resources are added here so that when they ARE
 * eventually loaded (on first feature open), the user always gets the freshest version.
 */
const TV_NETWORK_FIRST_FILES = [
  // 24-Hour TV engine files (lazy-loaded by SNXFeatureLoader on first tvPage visit)
  'snx-ch-adapter.js',
  'snx-tv-network.js',
  'snx-tv-network.css',
  'snx-theater.js',
  'snx-main-tv-feature.js',
  'snx-ch-broadcast.js',
  'snx-ch-control.js',
  'snx-creator-channels.js',
  'snx-ch-auth-bridge.js',
  'snx-ch-firebase.js',
  'snx-ch-engine.js',
  'channel.html',
  // SNS Live engine files (lazy-loaded by SNXFeatureLoader on first livePage visit)
  'live.js',
  'live.css',
  'snx-sfu.js',
  // Feature loader itself — network-first so a new build is always served
  'snx-feature-loader.js',
  // Radio engine files (lazy-loaded by SNXFeatureLoader on first radioPage visit)
  'snx-radio-track-store.js',
  'snx-radio.js',
  'snx-radio-player.js',
  'snx-radio-studio.js',
  'snx-radio-comments.js',
  'snx-radio-requests.js',
  'snx-radio-presence.js',
  'snx-radio.css',
  'snx-audio-coordinator.js',
  // DJ engine — network-first so mic v1.1.0 is never served from stale cache
  'snx-radio-dj.js',
  // Broadcast Engine — lazy-loaded by radio-studio feature; must always be fresh
  'snx-broadcast-engine.js',
  // Shadow Reaper AI — lazy-loaded by SNXFeatureLoader on first open; must always be fresh
  'snx-shadow-memory.js',
  'snx-shadow-conv-history.js',
  'snx-shadow-adaptive.js',
  'snx-shadow-ai.js',
  'snx-shadow-ai-knowledge.js',
  'snx-shadow-ai-e1.js',
  'snx-shadow-voice.js',
  'snx-shadow-character.js',
  // Shadow Reaper AI CSS — lazy-loaded with the shadow-ai feature; must always be fresh
  'snx-shadow-ai.css',
  'snx-shadow-voice.css',
  'snx-shadow-character.css',
];

const PRECACHE_URLS = SHELL_FILES.map(f => BASE + f);

/** Hosts that must always go to the network */
const NETWORK_ONLY_HOSTS = [
  'firestore.googleapis.com',
  'firebase.googleapis.com',
  'identitytoolkit.googleapis.com',
  'securetoken.googleapis.com',
  'firebaseinstallations.googleapis.com',
  'www.gstatic.com',
  'firebaseio.com',
  'googleapis.com',
  // Cloudflare upload worker + R2 CDN — never cache, always network
  'workers.dev',
  'cloudflare.com',
  'cdn.shadownexus.social',
  'photos.shadownexus.social',
  'r2.dev',
];

/* ─────────────────────────────────────────────
   INSTALL — pre-cache the app shell
   skipWaiting() is called so the new SW takes
   over as soon as it is installed, rather than
   waiting for all tabs to close. The page-side
   controllerchange handler (index.html) will
   reload once, guarded by sessionStorage so it
   cannot loop.
   ───────────────────────────────────────────── */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) =>
        Promise.allSettled(
          PRECACHE_URLS.map((url) =>
            cache.add(url).catch((err) =>
              console.warn(`[SW] Pre-cache skipped: ${url}`, err.message)
            )
          )
        )
      )
    // NOTE: skipWaiting() is intentionally NOT called automatically here.
    // Auto-skipWaiting causes the SW to take over mid-session on Android,
    // which results in a page reload that destroys the active Firebase Auth
    // session and forces re-login.
    // The new SW activates naturally when all tabs are closed and reopened.
    // The page explicitly sends SKIP_WAITING (below) only when the user
    // acknowledges the update toast — that path is safe.
  );
});

/* ─────────────────────────────────────────────
   ACTIVATE — clean up old caches, claim clients
   clients.claim() is called so new installs
   (fresh browser, cleared site data) take control
   of existing pages immediately.
   For update deployments the SW waits for all
   tabs to close naturally (no auto-skipWaiting),
   so claim() is a no-op until that happens.
   ───────────────────────────────────────────── */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) =>
        Promise.all(
          names
            .filter((n) => n !== CACHE_NAME && n !== MEDIA_CACHE)
            .map((n) => {
              console.log(`[SW] Deleting old cache: ${n}`);
              return caches.delete(n);
            })
        )
      )
      .then(() => self.clients.claim())
  );
});

/* ─────────────────────────────────────────────
   FETCH — request routing
   ───────────────────────────────────────────── */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle GET
  if (request.method !== 'GET') return;

  // Network-only: Firebase & external API hosts
  if (NETWORK_ONLY_HOSTS.some((host) => url.hostname.includes(host))) {
    event.respondWith(fetch(request));
    return;
  }

  // Navigation requests (page loads) — network-first, cache fallback, then offline page
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() =>
          caches.match(request).then(
            (cached) => cached || caches.match(OFFLINE)
          )
        )
    );
    return;
  }

  // Live streaming files — always network, never cache
  const pathname = url.pathname;
  if (url.origin === self.location.origin &&
      NETWORK_FIRST_PATHS.some(p => pathname.endsWith(p))) {
    event.respondWith(fetch(request));
    return;
  }

  // TV engine JS files — network-first, cache only as offline fallback.
  // This ensures the deployed TV code is always preferred over a stale cache.
  if (url.origin === self.location.origin &&
      TV_NETWORK_FIRST_FILES.some(f => pathname.endsWith('/' + f) || pathname === BASE + f || pathname.includes(f))) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() =>
          // Offline fallback — serve cached version if available
          caches.match(request).then(
            (cached) => cached || new Response('', { status: 503, statusText: 'Service Unavailable' })
          )
        )
    );
    return;
  }

  // Same-origin assets — cache-first, network fallback
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        }).catch(() =>
          new Response('', { status: 404, statusText: 'Not Found' })
        );
      })
    );
    return;
  }

  // Cross-origin CDN media (images, avatars) — stale-while-revalidate with size cap
  const isMedia = /\.(jpe?g|png|gif|webp|svg|mp4|webm|mp3|m4a|ogg|opus)(\?|$)/i.test(url.pathname);
  if (isMedia) {
    event.respondWith(
      caches.open(MEDIA_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) {
          // Serve cached copy; revalidate in background
          const dateHeader = cached.headers.get('date');
          const age = dateHeader ? Date.now() - new Date(dateHeader).getTime() : Infinity;
          if (age < MEDIA_CACHE_MAX_AGE_MS) {
            return cached; // fresh enough — no revalidation needed
          }
          // Stale — refresh in background
          fetch(request).then((fresh) => {
            if (fresh && fresh.status === 200) {
              _trimMediaCache(cache).then(() => cache.put(request, fresh.clone()));
            }
          }).catch(() => {});
          return cached;
        }
        // Not in cache — fetch, store, then serve
        try {
          const response = await fetch(request);
          if (response && response.status === 200) {
            await _trimMediaCache(cache);
            cache.put(request, response.clone());
          }
          return response;
        } catch (_) {
          return caches.match(request);
        }
      })
    );
    return;
  }

  // Cross-origin non-media assets (fonts, scripts from CDN) — network-first, cache fallback
  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      })
      .catch(() => caches.match(request))
  );
});

/** Trim media cache to MEDIA_CACHE_MAX entries (LRU by insertion order). */
async function _trimMediaCache(cache) {
  const keys = await cache.keys();
  if (keys.length >= MEDIA_CACHE_MAX) {
    const toDelete = keys.slice(0, keys.length - MEDIA_CACHE_MAX + 1);
    await Promise.all(toDelete.map((k) => cache.delete(k)));
  }
}

/* ─────────────────────────────────────────────
   MESSAGE — cache control from the page
   ───────────────────────────────────────────── */
/** Current network tier reported by snx-net.js on any page */
let _snxNetTier     = 'good';
let _snxDataSaver   = false;
let _snxOffline     = false;

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    // Honour explicit skip-waiting requests from the page (e.g. update prompt)
    self.skipWaiting();
  }
  if (event.data?.type === 'CLEAR_CACHE') {
    caches.delete(CACHE_NAME).then(() => {
      event.source?.postMessage({ type: 'CACHE_CLEARED' });
    });
  }
  if (event.data?.type === 'CHECK_UPDATE') {
    // Client asked if there's a newer SW ready; respond immediately
    event.source?.postMessage({
      type:       'UPDATE_STATUS',
      hasUpdate:  false,  // SW itself can't self-inspect; client handles via reg.waiting
    });
  }
  if (event.data?.type === 'GET_VERSION') {
    // Let the page know which build this SW is running
    event.source?.postMessage({ type: 'SW_VERSION', version: CACHE_VERSION, buildId: BUILD_ID });
  }

  // ── SNX-NET: network quality state update from snx-net.js ──
  if (event.data?.type === 'SNX_NET_STATE') {
    _snxNetTier   = event.data.tier      ?? 'good';
    _snxDataSaver = event.data.dataSaver ?? false;
    _snxOffline   = event.data.offline   ?? false;
    // On data-saver tier: trim media cache more aggressively
    if (_snxDataSaver) {
      caches.open(MEDIA_CACHE).then(cache => {
        cache.keys().then(keys => {
          // Keep only the 30 most-recently-cached items when bandwidth is tight
          if (keys.length > 30) {
            keys.slice(0, keys.length - 30).forEach(k => cache.delete(k));
          }
        });
      }).catch(() => {});
    }
  }
});
